package com.flp.pms.service.junit;


	import static org.junit.Assert.*;

	import java.util.ArrayList;
	import org.junit.Test;
	import com.flp.pms.domain.Product;
	import com.flp.pms.service.ProductServiceImpl;

	public class ProductServiceImplTestCases 
	{
		Product product = new Product();
		 ProductServiceImpl psi = new ProductServiceImpl();
		@Test
		public  void productId()
		{
			int i =psi.generateProductId();
			String str = ""+i;
			assertEquals(4,str.length());
	}
		
	}


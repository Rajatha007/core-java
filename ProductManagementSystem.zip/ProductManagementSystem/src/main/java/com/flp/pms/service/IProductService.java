package com.flp.pms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.Sub_Category;
import com.flp.pms.domain.Supplier;

public interface IProductService
{
	public  List<Category> getAllCategory();
	public List<Sub_Category> getAllSubCategory();
	public List<Supplier> getAllSupplier();
	public List<Discount> getAllDiscounts() ;
	public void addProduct(Product product);
	public void viewAllProducts();
	public boolean removeProduct() ;
	public ArrayList<Product> searchByProductName();
	public ArrayList<Product>  searchBySupplierName();
	public ArrayList<Product>  searchByCategoryName();
	public ArrayList<Product>  searchBySubCategory();
	public ArrayList<Product>  searchByRatings();
	
	public boolean validateProductId(int productId);
	public Map<Integer, Product> updateProductName(int productId,Product p, String pName); 
	public Map<Integer, Product> updateRetailPrice(int productId,Product p, double price); 
	public Map<Integer, Product> updateExpiryDate(int productId,Product p,Date date); 
	public Map<Integer, Product> updateRating(int productId,Product p,float ratings); 
	public Map<Integer, Product> updateCategory(int productId,Product p,Category category); 
}



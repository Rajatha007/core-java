package com.flp.pms.domain;

public class Category 																
{
	private int category_Id;
	private String category_Name;
	private String discription;	
	
	//Default Constructor
	public Category() {	}															

	//Constructor with arguments
	public Category(int category_Id, String category_Name, String discription) 			
	{
		super();
		this.category_Id = category_Id;
		this.category_Name = category_Name;
		this.discription = discription;
	}
	
	// Generate getters and setters
	
	public int getCategory_Id() {
		return category_Id;
	}
	public void setCategory_Id(int category_Id) {
		this.category_Id = category_Id;
	}
	public String getCategory_Name() {
		return category_Name;
	}
	public void setCategory_Name(String category_Name) {
		this.category_Name = category_Name;
	}
	public String getDiscription() {
		return discription;
	}
	public void setDiscription(String discription) {
		this.discription = discription;
	}

	//Overriding toString() methods
	@Override
	public String toString() {
		return "Category [category_Id=" + category_Id + ", category_Name=" + category_Name + ", discription="
				+ discription + "]";
	}

	//Overriding hashcode and equals method
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + category_Id;
		result = prime * result + ((category_Name == null) ? 0 : category_Name.hashCode());
		result = prime * result + ((discription == null) ? 0 : discription.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Category other = (Category) obj;
		if (category_Id != other.category_Id)
			return false;
		if (category_Name == null) {
			if (other.category_Name != null)
				return false;
		} else if (!category_Name.equals(other.category_Name))
			return false;
		if (discription == null) {
			if (other.discription != null)
				return false;
		} else if (!discription.equals(other.discription))
			return false;
		return true;
	}
	
	
}
